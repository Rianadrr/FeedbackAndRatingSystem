package com.example.feedback.controller;

import com.example.feedback.entity.Feedback;
import com.example.feedback.entity.User;
import com.example.feedback.repository.FeedbackRepository;
import com.example.feedback.repository.UserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.*;

@RestController
@RequestMapping("/api")
public class FeedbackController {

    private final FeedbackRepository feedbackRepo;
    private final UserRepository userRepo;

    public FeedbackController(FeedbackRepository feedbackRepo, UserRepository userRepo) {
        this.feedbackRepo = feedbackRepo;
        this.userRepo = userRepo;
    }

    @PostMapping("/feedbacks")
    public ResponseEntity<?> createFeedback(@Valid @RequestBody Feedback feedback) {
        return ResponseEntity.ok(feedbackRepo.save(feedback));
    }

    @GetMapping("/feedbacks")
    public ResponseEntity<?> getAllFeedbacks(@RequestParam(required = false) Integer rating) {
        if (rating != null) {
            return ResponseEntity.ok(feedbackRepo.findByRating(rating));
        }
        return ResponseEntity.ok(feedbackRepo.findAll());
    }

    @GetMapping("/feedbacks/{id}")
    public ResponseEntity<?> getFeedback(@PathVariable Long id) {
        return feedbackRepo.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/feedbacks/{id}")
    public ResponseEntity<?> updateFeedback(@PathVariable Long id, @Valid @RequestBody Feedback updated) {
        return feedbackRepo.findById(id).map(fb -> {
            fb.setMessage(updated.getMessage());
            fb.setRating(updated.getRating());
            fb.setUser(updated.getUser());
            return ResponseEntity.ok(feedbackRepo.save(fb));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/feedbacks/{id}")
    public ResponseEntity<?> deleteFeedback(@PathVariable Long id) {
        return feedbackRepo.findById(id).map(fb -> {
            feedbackRepo.delete(fb);
            return ResponseEntity.ok("Feedback dihapus");
        }).orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/ratings-summary")
    public ResponseEntity<?> ratingsSummary() {
        List<Feedback> all = feedbackRepo.findAll();
        if (all.isEmpty()) {
            return ResponseEntity.ok(Collections.singletonMap("average", 0));
        }
        double avg = all.stream().mapToInt(Feedback::getRating).average().orElse(0);
        return ResponseEntity.ok(Collections.singletonMap("average", avg));
    }

    @PostMapping("/users")
    public ResponseEntity<?> createUser(@Valid @RequestBody User user) {
        return ResponseEntity.ok(userRepo.save(user));
    }

    @GetMapping("/users/{id}/feedbacks")
    public ResponseEntity<?> getUserFeedbacks(@PathVariable Long id) {
        if (!userRepo.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(feedbackRepo.findByUserId(id));
    }
}
